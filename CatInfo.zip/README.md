# CatInfo

Ever Wanted More Accurate Stats? Then Heres CatInfo This Is a Addon To <a href="https://rounds.thunderstore.io/package/willuwontu/TabInfo/">TabInfo</a> Which Allows You To See Alot More Stats
Now Featuring Configs To Toggle Any Stat You Want On Or Off (Configs are like performance improvements they wont have to be reset each time you make a new profile)

Credit To
<ul>
<li><a href="https://rounds.thunderstore.io/package/Root/">『Root』</a></li>
<li><a href="https://rounds.thunderstore.io/package/willuwontu/">willuwontu</a></li>
<li><a href="https://rounds.thunderstore.io/package/willis81808/">Willis</a></li>
</ul>