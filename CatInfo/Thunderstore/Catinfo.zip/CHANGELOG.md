
## Patch Notes
<details>
   <summary>   
<code>Update 2.4.0</code>
	</summary>
<code>fixed up a bit of the names of the stats, added config to allways show stats and updated dependencys</code>
</details>
<details>
   <summary>   
<code>Update 2.3.0</code>
	</summary>
<code>removed toggles and menu in favor of the tabinfo update</code>
</details>
<details>
   <summary>   
<code>Update 2.2.4</code>
	</summary>
<code>fixed typo and made description more "informative"</code>
</details>
 <summary>   
<code>Update 2.2.3</code>
	</summary>
<code>Updated the png to an apng to hopefuly add the gif i made it as</code>
</details>
<details>
   <summary>   
<code>Update 2.2.2</code>
	</summary>
<code>Fixed Patch Notes to showup cus i named the file the wrong name</code>
</details>
<details>
   <summary>   
<code>Update 2.2.1</code>
	</summary>
<code>Updated README & Added credit menu <s>& added Patch Notes</s></code>
</details>
<details>
   <summary>   
 <code>Update 2.2.0</code>
	</summary>
<code>Added Presets & Also changed more names</code>
</details>
<details>
   <summary>   
 <code>Update 2.1.2</code>
	</summary>
<code>Fixed the stupid error from duplicate names that fucked shit up</code>
</details>
<details>
   <summary>   
<code>Update 2.1.1</code>
	</summary>
<code><s>Fixed the configs menu</s> & Merged Basic Stats Extended with Basic Stats</code>
</details>
<details>
   <summary>  
<code>Update 2.1.0</code>
</summary>
<code>Added configs for all stats & More stats and renamed more</code>
	</details>
<details>
   <summary>  
<code>Update 2.0.0</code>
	</summary>
<code>Added lots more stats</code>
</details>
<details>
   <summary>  
<code>Update 1.0.1</code>
</summary>
<code>Fixed willuwonto to willuwontu in the README credits</code>
</details>
<details>
   <summary>  
<code>Update 1.0.0</code>
</summary>
<code>Release</code>
</details>
