
# CatInfo

Have you ever wanted more accurate stats? then here's CatInfo this mod is an add-on to 
[TabInfo](https://rounds.thunderstore.io/package/willreuploadscuzheruinedstuff/TabInfo/).
CatInfo adds lots of stats that are all toggleable.
Most stats are disabled by default 




## Special Thanks To
>-  [『 Root 』](https://rounds.thunderstore.io/package/Root/)
>-  [willuwontu](https://rounds.thunderstore.io/package/willuwontu/ )
>-  [willuwontu](https://rounds.thunderstore.io/package/willreuploadscuzheruinedstuff/ )
>-  [Willis](https://rounds.thunderstore.io/package/willis81808/)
